<?php
require_once "functions.php";
logout();